package com.b866f.launcher.widget

import android.content.Context
import android.util.AttributeSet
import android.widget.FrameLayout

/** Placeholder custom view; settings are currently exposed through MainActivity dialog. */
class RightSettingsSidebarView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : FrameLayout(context, attrs)
