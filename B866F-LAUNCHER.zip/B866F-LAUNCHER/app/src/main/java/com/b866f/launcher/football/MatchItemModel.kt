package com.b866f.launcher.football

data class MatchItemModel(
    val id: String,
    val leagueCode: String,
    val leagueName: String,
    val homeTeam: String,
    val awayTeam: String,
    val kickoffWib: String,
    val isLive: Boolean = false,
    val liveMinute: String? = null
)
