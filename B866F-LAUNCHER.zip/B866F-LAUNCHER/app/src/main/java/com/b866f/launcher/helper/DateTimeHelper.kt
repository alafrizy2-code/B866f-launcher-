package com.b866f.launcher.helper

import android.os.Handler
import android.os.Looper
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.*

object DateTimeHelper {
    private val handler = Handler(Looper.getMainLooper())
    private var task: Runnable? = null
    fun getFormattedCurrentDate(): String =
        SimpleDateFormat("EEEE dd MMMM yyyy", Locale("id", "ID")).format(Date()).uppercase(Locale("id", "ID"))

    fun convertUtcToWibTime(value: String): String = try {
        val patterns = listOf("yyyy-MM-dd'T'HH:mm:ss'Z'", "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
        val date = patterns.firstNotNullOfOrNull { pattern ->
            try { SimpleDateFormat(pattern, Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }.parse(value) }
            catch (_: Exception) { null }
        } ?: return "--:--"
        SimpleDateFormat("HH:mm", Locale("id", "ID")).apply {
            timeZone = TimeZone.getTimeZone("Asia/Jakarta")
        }.format(date)
    } catch (_: Exception) { "--:--" }

    fun bindToTextView(view: TextView) {
        task?.let { handler.removeCallbacks(it) }
        task = object : Runnable {
            override fun run() { view.text = getFormattedCurrentDate(); handler.postDelayed(this, 60_000) }
        }
        task?.run()
    }
    fun stop() { task?.let { handler.removeCallbacks(it) }; task = null }
}
