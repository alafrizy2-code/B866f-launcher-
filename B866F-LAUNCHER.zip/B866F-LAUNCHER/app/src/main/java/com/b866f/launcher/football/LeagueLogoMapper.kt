package com.b866f.launcher.football

import com.b866f.launcher.R

object LeagueLogoMapper {
    fun getLogoDrawable(code: String): Int = when (code.uppercase()) {
        "CL" -> R.drawable.ic_ucl
        "EL" -> R.drawable.ic_uel
        "PL" -> R.drawable.ic_pl
        "PD" -> R.drawable.ic_laliga
        "SA" -> R.drawable.ic_seriea
        "BL1" -> R.drawable.ic_bundesliga
        "LIGA1" -> R.drawable.ic_liga1
        else -> R.drawable.ic_ucl
    }
}
