package com.b866f.launcher.widget

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.util.AttributeSet
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import androidx.annotation.ColorInt
import com.b866f.launcher.football.FootballApiService
import com.b866f.launcher.football.MatchItemModel
import kotlinx.coroutines.*

class KickOffWidgetView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : LinearLayout(context, attrs, defStyleAttr) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val service = FootballApiService(context)
    private val content = LinearLayout(context).apply { orientation = VERTICAL }
    private var accent = Color.parseColor("#FF80AB")
    init {
        orientation = VERTICAL
        setPadding(14, 12, 14, 12)
        background = GradientDrawable().apply { setColor(0x66000000); cornerRadius = 16f; setStroke(1, 0x44FFFFFF) }
        val header = TextView(context).apply { text = "KICK-OFF HARI INI  •  WIB"; setTextColor(Color.WHITE); textSize = 13f }
        addView(header)
        addView(content)
        refreshMatches()
    }
    fun setAccentColor(@ColorInt color: Int, @ColorInt draftBackground: Int) {
        accent = color
        refreshMatches()
    }
    fun refreshMatches() {
        scope.launch {
            val matches = withContext(Dispatchers.IO) { service.getUpcomingMatches() }
            content.removeAllViews()
            if (matches.isEmpty()) {
                content.addView(TextView(context).apply {
                    text = "Jadwal belum tersedia. Hubungkan token API untuk data pertandingan."
                    setTextColor(0xCCFFFFFF.toInt()); textSize = 11f; setPadding(0, 8, 0, 0)
                })
            } else matches.take(8).forEach { match ->
                content.addView(TextView(context).apply {
                    text = "${match.kickoffWib} WIB  •  ${match.homeTeam} vs ${match.awayTeam}"
                    setTextColor(Color.WHITE); textSize = 12f; setPadding(0, 7, 0, 7)
                })
            }
        }
    }
    override fun onDetachedFromWindow() { scope.cancel(); super.onDetachedFromWindow() }
}
