package com.b866f.launcher.helper

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.widget.ImageView
import com.b866f.launcher.R

class WallpaperHelper(private val context: Context) {
    companion object {
        private const val PREFS = "b866f_wallpaper_prefs"
        private const val KEY = "wallpaper_uri"
        const val REQUEST_PICK_WALLPAPER = 1001
        fun openWallpaperPicker(activity: Activity) {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "image/*"
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }
            activity.startActivityForResult(intent, REQUEST_PICK_WALLPAPER)
        }
    }
    fun saveWallpaperUri(uri: Uri) {
        try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, uri.toString()).apply()
    }
    fun resetToDefault() { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY).apply() }
    fun applyWallpaper(view: ImageView) {
        val saved = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
        try {
            if (saved != null) {
                context.contentResolver.openInputStream(Uri.parse(saved))?.use {
                    val bmp = BitmapFactory.decodeStream(it)
                    if (bmp != null) { view.setImageBitmap(bmp); return }
                }
            }
        } catch (_: Exception) {}
        view.setImageResource(R.drawable.wallpaper_lake_mountains)
    }
}
