package com.b866f.launcher

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.b866f.launcher.helper.DateTimeHelper
import com.b866f.launcher.helper.WallpaperHelper
import com.b866f.launcher.theme.ThemeManager
import com.b866f.launcher.widget.KickOffWidgetView

class MainActivity : AppCompatActivity() {
    private lateinit var wallpaper: ImageView
    private lateinit var date: TextView
    private lateinit var weather: TextView
    private lateinit var kickoff: KickOffWidgetView
    private lateinit var bottom: LinearLayout
    private lateinit var themeManager: ThemeManager
    private lateinit var wallpaperHelper: WallpaperHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        themeManager = ThemeManager.getInstance(this)
        wallpaperHelper = WallpaperHelper(this)
        buildScreen()
        wallpaperHelper.applyWallpaper(wallpaper)
        DateTimeHelper.bindToTextView(date)
    }

    private fun buildScreen() {
        val root = FrameLayout(this)
        wallpaper = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        root.addView(wallpaper, FrameLayout.LayoutParams(-1, -1))
        val shade = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 28, 36, 24)
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val brand = TextView(this).apply {
            text = "B866F\nLAUNCHER"
            textSize = 26f
            setTextColor(Color.WHITE)
            setShadowLayer(5f, 2f, 2f, Color.BLACK)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        top.addView(brand)
        val spacer = Space(this)
        top.addView(spacer, LinearLayout.LayoutParams(0, 1, 1f))
        fun iconButton(label: String, action: () -> Unit): TextView =
            TextView(this).apply {
                text = label
                textSize = 22f
                setTextColor(Color.WHITE)
                setPadding(12, 8, 12, 8)
                isFocusable = true
                setOnClickListener { action() }
            }
        top.addView(iconButton("◉") { startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)) })
        top.addView(iconButton("🎙") { Toast.makeText(this, "Voice search belum tersedia", Toast.LENGTH_SHORT).show() })
        top.addView(iconButton("ᛒ") { startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) })
        top.addView(iconButton("⚙") { showSettings() })
        shade.addView(top)
        date = TextView(this).apply { textSize = 15f; setTextColor(Color.WHITE); setPadding(0, 12, 0, 4) }
        shade.addView(date)
        weather = TextView(this).apply { text = "Cuaca Medan • data cuaca belum dihubungkan"; textSize = 13f; setTextColor(Color.WHITE) }
        shade.addView(weather)
        kickoff = KickOffWidgetView(this)
        shade.addView(kickoff, LinearLayout.LayoutParams(310, -2).apply { topMargin = 18 })
        val bottomSpacer = Space(this)
        shade.addView(bottomSpacer, LinearLayout.LayoutParams(1, 0, 1f))
        bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(16, 14, 16, 14)
            setBackgroundColor(0x99000000.toInt())
        }
        listOf("CloudStream", "GVision", "bit tv", "TizenTube", "PPSSPP", "YouTube").forEach { app ->
            val tv = TextView(this).apply {
                text = app
                textSize = 14f
                setTextColor(Color.WHITE)
                setPadding(12, 14, 12, 14)
                isFocusable = true
                setOnClickListener { Toast.makeText(this@MainActivity, "$app: pilih aplikasi dari perangkat", Toast.LENGTH_SHORT).show() }
            }
            bottom.addView(tv)
        }
        shade.addView(bottom)
        root.addView(shade, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
    }

    private fun showSettings() {
        val choices = arrayOf("Ganti wallpaper", "Reset wallpaper", "Pilih tema", "Pengaturan Android")
        AlertDialog.Builder(this).setTitle("Pengaturan B866F Launcher")
            .setItems(choices) { _, which ->
                when (which) {
                    0 -> WallpaperHelper.openWallpaperPicker(this)
                    1 -> { wallpaperHelper.resetToDefault(); wallpaperHelper.applyWallpaper(wallpaper) }
                    2 -> {
                        val themes = ThemeManager.PRESET_LIST
                        AlertDialog.Builder(this).setTitle("Pilih tema")
                            .setItems(themes.map { it.name }.toTypedArray()) { _, index ->
                                themeManager.applyPreset(themes[index])
                                kickoff.setAccentColor(themes[index].accentColor, themes[index].draftBackgroundColor)
                            }.show()
                    }
                    3 -> startActivity(Intent(Settings.ACTION_SETTINGS))
                }
            }.show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == WallpaperHelper.REQUEST_PICK_WALLPAPER && resultCode == Activity.RESULT_OK) {
            data?.data?.let { wallpaperHelper.saveWallpaperUri(it); wallpaperHelper.applyWallpaper(wallpaper) }
        }
    }

    override fun onDestroy() {
        DateTimeHelper.stop()
        super.onDestroy()
    }
}
