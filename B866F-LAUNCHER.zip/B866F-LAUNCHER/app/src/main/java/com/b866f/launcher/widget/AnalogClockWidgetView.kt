package com.b866f.launcher.widget

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import java.util.Calendar

class AnalogClockWidgetView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f; val cy = height / 2f
        val r = minOf(cx, cy) * .9f
        paint.color = 0x66000000; paint.style = Paint.Style.FILL
        canvas.drawCircle(cx, cy, r, paint)
        val cal = Calendar.getInstance()
        val h = cal.get(Calendar.HOUR); val m = cal.get(Calendar.MINUTE); val s = cal.get(Calendar.SECOND)
        fun hand(angle: Float, length: Float, width: Float, color: Int) {
            paint.color = color; paint.strokeWidth = width; paint.strokeCap = Paint.Cap.ROUND
            val rad = Math.toRadians((angle - 90).toDouble())
            canvas.drawLine(cx, cy, cx + kotlin.math.cos(rad).toFloat() * length, cy + kotlin.math.sin(rad).toFloat() * length, paint)
        }
        hand((h * 30 + m * .5f), r * .5f, 5f, Color.WHITE)
        hand(m * 6f, r * .72f, 3f, Color.WHITE)
        hand(s * 6f, r * .82f, 1.5f, Color.MAGENTA)
        paint.color = Color.WHITE; canvas.drawCircle(cx, cy, 4f, paint)
        postInvalidateDelayed(1000)
    }
}
