package com.b866f.launcher.theme

import android.content.Context
import android.graphics.Color

class ThemeManager private constructor(context: Context) {
    private val prefs = context.getSharedPreferences("b866f_theme_prefs", Context.MODE_PRIVATE)
    data class ThemeConfig(val id: String, val name: String, val accentColor: Int, val draftBackgroundColor: Int)
    companion object {
        val PRESET_LIST = listOf(
            ThemeConfig("pink", "Default Pink", Color.parseColor("#FF80AB"), 0x99000000.toInt()),
            ThemeConfig("blue", "Dark Blue", Color.parseColor("#00E5FF"), 0x990D47A1.toInt()),
            ThemeConfig("green", "Emerald Green", Color.parseColor("#69F0AE"), 0x991B5E20.toInt()),
            ThemeConfig("white", "Midnight White", Color.WHITE, 0xCC121212.toInt()),
            ThemeConfig("red", "Arsenal Red", Color.parseColor("#EF0107"), 0x99B71C1C.toInt())
        )
        @Volatile private var instance: ThemeManager? = null
        fun getInstance(context: Context): ThemeManager = instance ?: synchronized(this) {
            instance ?: ThemeManager(context.applicationContext).also { instance = it }
        }
    }
    fun applyPreset(theme: ThemeConfig) { prefs.edit().putString("theme_id", theme.id).apply() }
    fun getCurrentTheme(): ThemeConfig = PRESET_LIST.firstOrNull {
        it.id == prefs.getString("theme_id", "pink")
    } ?: PRESET_LIST.first()
}
