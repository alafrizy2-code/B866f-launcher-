package com.b866f.launcher.football

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import com.b866f.launcher.helper.DateTimeHelper

class FootballApiService(private val context: Context) {
    fun getUpcomingMatches(forceRefresh: Boolean = false): List<MatchItemModel> {
        val token = BuildConfigToken.value
        if (token.isBlank()) return emptyList()
        val result = mutableListOf<MatchItemModel>()
        var connection: HttpURLConnection? = null
        try {
            connection = (URL("https://api.football-data.org/v4/matches?competitions=CL,EL,PL,PD,SA,BL1&status=SCHEDULED,LIVE").openConnection() as HttpURLConnection).apply {
                connectTimeout = 7000; readTimeout = 7000
                setRequestProperty("X-Auth-Token", token)
            }
            if (connection.responseCode == 200) {
                val root = JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
                val matches = root.optJSONArray("matches") ?: return emptyList()
                for (i in 0 until matches.length()) {
                    val item = matches.getJSONObject(i)
                    val comp = item.optJSONObject("competition") ?: continue
                    val status = item.optString("status")
                    result.add(MatchItemModel(
                        item.optString("id"), comp.optString("code"), comp.optString("name"),
                        item.optJSONObject("homeTeam")?.optString("name") ?: "TBD",
                        item.optJSONObject("awayTeam")?.optString("name") ?: "TBD",
                        DateTimeHelper.convertUtcToWibTime(item.optString("utcDate")),
                        status == "IN_PLAY" || status == "PAUSED",
                        null
                    ))
                }
            }
        } catch (_: Exception) {
        } finally { connection?.disconnect() }
        return result
    }
    private object BuildConfigToken {
        val value: String = System.getenv("FOOTBALL_DATA_TOKEN") ?: ""
    }
}
