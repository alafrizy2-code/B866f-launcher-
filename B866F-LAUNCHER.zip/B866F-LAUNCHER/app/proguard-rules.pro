# B866F LAUNCHER - aturan awal
-keepattributes *Annotation*
