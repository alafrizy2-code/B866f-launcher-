# B866F LAUNCHER v2.1.4 — starter project

Project Android TV launcher untuk ZTE B866F. Struktur Gradle dan workflow GitHub Actions sudah disiapkan.

## Build APK dari GitHub
1. Upload seluruh isi ZIP ini ke repository GitHub baru.
2. Buka tab **Actions**.
3. Pilih **Build B866F Launcher APK** lalu tekan **Run workflow**.
4. Setelah selesai, buka hasil run dan unduh artifact `B866F-Launcher-debug-apk`.
5. Install APK debug di STB untuk pengujian.

## Catatan penting
- Build awal menggunakan APK **debug** yang otomatis ditandatangani debug key; cocok untuk uji coba.
- `gradlew` dan wrapper JAR tidak disertakan. Workflow memasang Gradle 8.2 di runner GitHub dan menjalankan perintah `gradle` langsung.
- Token API sepak bola tidak ditanam di source. Tambahkan token melalui GitHub Secrets `FOOTBALL_DATA_TOKEN` bila nanti mengaktifkan API.
- Jadwal Liga 1 contoh tidak ditampilkan sebagai jadwal nyata. Hubungkan sumber data resmi sebelum mengaktifkan pertandingan aktual.
- Ini fondasi project yang dapat dibuild, bukan jaminan kompatibilitas pada semua firmware B866F. Uji di perangkat terlebih dahulu.
