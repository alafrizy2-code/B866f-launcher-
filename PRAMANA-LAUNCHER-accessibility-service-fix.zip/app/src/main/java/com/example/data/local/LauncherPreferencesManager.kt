package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.LauncherPreferences
import com.example.data.model.ScaleMode
import com.example.data.model.WallpaperConfig
import com.example.data.model.WallpaperType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class LauncherPreferencesManager(private val context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("pramana_launcher_prefs", Context.MODE_PRIVATE)

    private val _preferencesFlow = MutableStateFlow(loadPreferences())
    val preferencesFlow: StateFlow<LauncherPreferences> = _preferencesFlow.asStateFlow()

    private val _wallpaperFlow = MutableStateFlow(loadWallpaperConfig())
    val wallpaperFlow: StateFlow<WallpaperConfig> = _wallpaperFlow.asStateFlow()

    private val _dockOrderFlow = MutableStateFlow(loadDockOrder())
    val dockOrderFlow: StateFlow<List<String>> = _dockOrderFlow.asStateFlow()

    private val _hiddenAppsFlow = MutableStateFlow(loadHiddenApps())
    val hiddenAppsFlow: StateFlow<Set<String>> = _hiddenAppsFlow.asStateFlow()

    fun loadPreferences(): LauncherPreferences {
        return LauncherPreferences(
            showAnalogClock = prefs.getBoolean(KEY_SHOW_ANALOG_CLOCK, true),
            showFootballWidget = prefs.getBoolean(KEY_SHOW_FOOTBALL_WIDGET, true),
            is24HourFormat = prefs.getBoolean(KEY_IS_24_HOUR, true),
            dockScale = prefs.getFloat(KEY_DOCK_SCALE, 1.0f),
            footballApiKey = prefs.getString(KEY_FOOTBALL_API_KEY, "") ?: "",
            autoRefreshFootball = prefs.getBoolean(KEY_AUTO_REFRESH_FOOTBALL, true),
            selectedLeagueCode = prefs.getString(KEY_SELECTED_LEAGUE, "PL") ?: "PL"
        )
    }

    fun updatePreferences(transform: (LauncherPreferences) -> LauncherPreferences) {
        val current = _preferencesFlow.value
        val updated = transform(current)
        prefs.edit().apply {
            putBoolean(KEY_SHOW_ANALOG_CLOCK, updated.showAnalogClock)
            putBoolean(KEY_SHOW_FOOTBALL_WIDGET, updated.showFootballWidget)
            putBoolean(KEY_IS_24_HOUR, updated.is24HourFormat)
            putFloat(KEY_DOCK_SCALE, updated.dockScale)
            putString(KEY_FOOTBALL_API_KEY, updated.footballApiKey)
            putBoolean(KEY_AUTO_REFRESH_FOOTBALL, updated.autoRefreshFootball)
            putString(KEY_SELECTED_LEAGUE, updated.selectedLeagueCode)
            apply()
        }
        _preferencesFlow.value = updated
    }

    fun loadWallpaperConfig(): WallpaperConfig {
        val typeStr = prefs.getString(KEY_WALLPAPER_TYPE, WallpaperType.PRESET.name)
        val type = try {
            WallpaperType.valueOf(typeStr ?: WallpaperType.PRESET.name)
        } catch (_: Exception) {
            WallpaperType.PRESET
        }
        val presetId = prefs.getString(KEY_WALLPAPER_PRESET, "neon_cyber") ?: "neon_cyber"
        val customUri = prefs.getString(KEY_WALLPAPER_CUSTOM_URI, null)
        val scaleStr = prefs.getString(KEY_WALLPAPER_SCALE, ScaleMode.CENTER_CROP.name)
        val scale = try {
            ScaleMode.valueOf(scaleStr ?: ScaleMode.CENTER_CROP.name)
        } catch (_: Exception) {
            ScaleMode.CENTER_CROP
        }
        return WallpaperConfig(
            type = type,
            presetId = presetId,
            customUriString = customUri,
            scaleMode = scale
        )
    }

    fun saveWallpaperConfig(config: WallpaperConfig) {
        prefs.edit().apply {
            putString(KEY_WALLPAPER_TYPE, config.type.name)
            putString(KEY_WALLPAPER_PRESET, config.presetId)
            putString(KEY_WALLPAPER_CUSTOM_URI, config.customUriString)
            putString(KEY_WALLPAPER_SCALE, config.scaleMode.name)
            apply()
        }
        _wallpaperFlow.value = config
    }

    fun loadDockOrder(): List<String> {
        val raw = prefs.getString(KEY_DOCK_ORDER, "") ?: ""
        return if (raw.isBlank()) emptyList() else raw.split(",").map { it.trim() }
    }

    fun saveDockOrder(order: List<String>) {
        prefs.edit().putString(KEY_DOCK_ORDER, order.joinToString(",")).apply()
        _dockOrderFlow.value = order
    }

    fun loadHiddenApps(): Set<String> {
        return prefs.getStringSet(KEY_HIDDEN_APPS, emptySet()) ?: emptySet()
    }

    fun toggleAppHidden(packageName: String) {
        val current = loadHiddenApps().toMutableSet()
        if (current.contains(packageName)) {
            current.remove(packageName)
        } else {
            current.add(packageName)
        }
        prefs.edit().putStringSet(KEY_HIDDEN_APPS, current).apply()
        _hiddenAppsFlow.value = current
    }

    fun unhideAllApps() {
        prefs.edit().remove(KEY_HIDDEN_APPS).apply()
        _hiddenAppsFlow.value = emptySet()
    }

    companion object {
        private const val KEY_SHOW_ANALOG_CLOCK = "show_analog_clock"
        private const val KEY_SHOW_FOOTBALL_WIDGET = "show_football_widget"
        private const val KEY_IS_24_HOUR = "is_24_hour"
        private const val KEY_DOCK_SCALE = "dock_scale"
        private const val KEY_FOOTBALL_API_KEY = "football_api_key"
        private const val KEY_AUTO_REFRESH_FOOTBALL = "auto_refresh_football"
        private const val KEY_SELECTED_LEAGUE = "selected_league"

        private const val KEY_WALLPAPER_TYPE = "wallpaper_type"
        private const val KEY_WALLPAPER_PRESET = "wallpaper_preset"
        private const val KEY_WALLPAPER_CUSTOM_URI = "wallpaper_custom_uri"
        private const val KEY_WALLPAPER_SCALE = "wallpaper_scale"

        private const val KEY_DOCK_ORDER = "dock_order"
        private const val KEY_HIDDEN_APPS = "hidden_apps"
    }
}
