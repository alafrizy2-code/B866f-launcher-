package com.example.data.model

data class LauncherPreferences(
    val showAnalogClock: Boolean = true,
    val showFootballWidget: Boolean = true,
    val is24HourFormat: Boolean = true,
    val dockScale: Float = 1.0f,
    val footballApiKey: String = "",
    val autoRefreshFootball: Boolean = true,
    val selectedLeagueCode: String = "PL"
)
