package com.example.data.model

import android.graphics.drawable.Drawable

data class AppItem(
    val packageName: String,
    val activityName: String,
    val label: String,
    val isHidden: Boolean = false,
    val orderIndex: Int = 0,
    val isSystemApp: Boolean = false,
    @Transient val iconDrawable: Drawable? = null
)
