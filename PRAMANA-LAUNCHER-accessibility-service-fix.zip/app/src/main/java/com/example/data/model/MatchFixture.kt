package com.example.data.model

enum class MatchStatus(val label: String) {
    UPCOMING("Akan Main"),
    LIVE("LIVE"),
    FINISHED("Selesai"),
    POSTPONED("Ditunda")
}

data class LeagueInfo(
    val code: String,
    val name: String,
    val country: String,
    val iconName: String
)

data class MatchFixture(
    val id: String,
    val leagueCode: String,
    val leagueName: String,
    val homeTeam: String,
    val awayTeam: String,
    val homeTeamShort: String,
    val awayTeamShort: String,
    val homeLogoUrl: String,
    val awayLogoUrl: String,
    val matchDateWib: String,
    val matchTimeWib: String,
    val status: MatchStatus,
    val minute: String? = null,
    val scoreHome: Int? = null,
    val scoreAway: Int? = null
)
