package com.example.data.model

enum class WallpaperType {
    PRESET,
    CUSTOM_URI
}

enum class ScaleMode(val label: String) {
    CENTER_CROP("Center Crop"),
    FIT("Fit Layar"),
    STRETCH("Penuh (Stretch)")
}

data class WallpaperPreset(
    val id: String,
    val name: String,
    val drawableResName: String,
    val previewGradientHex: Long
)

data class WallpaperConfig(
    val type: WallpaperType = WallpaperType.PRESET,
    val presetId: String = "neon_cyber",
    val customUriString: String? = null,
    val scaleMode: ScaleMode = ScaleMode.CENTER_CROP
)
