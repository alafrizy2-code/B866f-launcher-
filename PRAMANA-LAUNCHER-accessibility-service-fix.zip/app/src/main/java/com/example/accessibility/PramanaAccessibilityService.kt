package com.example.accessibility

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

/**
 * Layanan minimal agar Android mengenali PRAMANA LAUNCHER sebagai
 * Accessibility Service yang valid. Tidak mengambil teks/isi layar,
 * tidak mengklik tombol, dan tidak mengubah pengaturan sistem.
 *
 * Catatan: layanan ini tidak diperlukan untuk memilih default HOME.
 */
class PramanaAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Sengaja tidak melakukan tindakan apa pun.
    }

    override fun onInterrupt() {
        // Tidak ada proses aktif yang perlu dihentikan.
    }
}
