package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.TvCardBg
import com.example.ui.theme.TvFocusBorder
import com.example.ui.theme.TvGlassBorder

@Composable
fun TvFocusableCard(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(14.dp),
    backgroundColor: Color = TvCardBg,
    focusedBorderColor: Color = TvFocusBorder,
    unfocusedBorderColor: Color = TvGlassBorder,
    focusedScale: Float = 1.06f,
    elevation: Dp = 6.dp,
    enabled: Boolean = true,
    content: @Composable BoxScope.(isFocused: Boolean) -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isFocused by interactionSource.collectIsFocusedAsState()

    val animatedScale by animateFloatAsState(
        targetValue = if (isFocused) focusedScale else 1f,
        animationSpec = tween(durationMillis = 180),
        label = "tv_focus_scale"
    )

    Surface(
        shape = shape,
        color = backgroundColor,
        border = BorderStroke(
            width = if (isFocused) 2.5.dp else 1.dp,
            color = if (isFocused) focusedBorderColor else unfocusedBorderColor
        ),
        shadowElevation = if (isFocused) elevation * 1.5f else elevation,
        modifier = modifier
            .scale(animatedScale)
            .shadow(
                elevation = if (isFocused) 12.dp else 2.dp,
                shape = shape,
                ambientColor = if (isFocused) focusedBorderColor else Color.Black,
                spotColor = if (isFocused) focusedBorderColor else Color.Black
            )
            .focusable(enabled = enabled, interactionSource = interactionSource)
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                enabled = enabled,
                onClick = onClick
            )
    ) {
        Box(content = { content(isFocused) })
    }
}
