package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.LeagueInfo
import com.example.data.model.MatchFixture
import com.example.data.model.MatchStatus
import com.example.ui.theme.TvCardBg
import com.example.ui.theme.TvCyanPrimary
import com.example.ui.theme.TvGlassBorder
import com.example.ui.theme.TvGlassSurface
import com.example.ui.theme.TvGoldAccent
import com.example.ui.theme.TvLiveGreen
import com.example.ui.theme.TvTextPrimary
import com.example.ui.theme.TvTextSecondary

@Composable
fun FootballScheduleWidget(
    leagues: List<LeagueInfo>,
    selectedLeagueCode: String,
    fixtures: List<MatchFixture>,
    isLoading: Boolean,
    onSelectLeague: (String) -> Unit,
    onRefresh: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxHeight()
            .clip(RoundedCornerShape(20.dp))
            .background(TvGlassSurface)
            .border(1.dp, TvGlassBorder, RoundedCornerShape(20.dp))
            .padding(14.dp)
    ) {
        Column(modifier = Modifier.fillMaxHeight()) {
            // Widget Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.SportsSoccer,
                        contentDescription = "Sepak Bola",
                        tint = TvCyanPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "JADWAL SEPAK BOLA",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp,
                        color = TvTextPrimary
                    )
                }

                TvFocusableCard(
                    onClick = onRefresh,
                    shape = RoundedCornerShape(8.dp),
                    backgroundColor = TvGlassBorder.copy(alpha = 0.2f),
                    focusedScale = 1.1f,
                    modifier = Modifier.size(28.dp)
                ) { isFocused ->
                    Box(
                        modifier = Modifier.size(28.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(14.dp),
                                strokeWidth = 2.dp,
                                color = TvCyanPrimary
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Perbarui Jadwal",
                                tint = if (isFocused) Color.White else TvTextSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // League Selector Chips (Horizontal Remote Scrollable)
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                contentPadding = PaddingValues(horizontal = 2.dp)
            ) {
                items(leagues) { league ->
                    val isSelected = league.code == selectedLeagueCode
                    TvFocusableCard(
                        onClick = { onSelectLeague(league.code) },
                        shape = RoundedCornerShape(20.dp),
                        backgroundColor = if (isSelected) TvCyanPrimary.copy(alpha = 0.25f) else Color(0x330F172A),
                        focusedBorderColor = TvCyanPrimary,
                        unfocusedBorderColor = if (isSelected) TvCyanPrimary else Color(0x22FFFFFF),
                        focusedScale = 1.08f,
                        elevation = 0.dp
                    ) { isFocused ->
                        Box(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = league.name,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected || isFocused) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) TvCyanPrimary else if (isFocused) Color.White else TvTextSecondary
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Fixtures List
            if (fixtures.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.SportsSoccer,
                            contentDescription = null,
                            tint = Color.Gray.copy(alpha = 0.5f),
                            modifier = Modifier.size(36.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Data jadwal belum tersedia saat ini",
                            fontSize = 12.sp,
                            color = TvTextSecondary,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    itemsIndexed(fixtures) { _, match ->
                        MatchFixtureCard(match = match)
                    }
                }
            }
        }
    }
}

@Composable
private fun MatchFixtureCard(match: MatchFixture) {
    TvFocusableCard(
        onClick = { /* Detail Match view or toast */ },
        shape = RoundedCornerShape(12.dp),
        backgroundColor = Color(0x550A0F1D),
        focusedScale = 1.04f,
        modifier = Modifier.fillMaxWidth()
    ) { isFocused ->
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp)
        ) {
            // Match Status & WIB Date
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${match.matchDateWib} • ${match.matchTimeWib}",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium,
                    color = TvTextSecondary
                )

                MatchStatusBadge(match.status, match.minute)
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Teams and Score / VS
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Home Team
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TeamLogoImage(url = match.homeLogoUrl, teamName = match.homeTeam)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = match.homeTeam,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // Score or Kickoff Time
                Box(
                    modifier = Modifier
                        .padding(horizontal = 6.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0x33000000))
                        .padding(horizontal = 8.dp, vertical = 3.dp),
                    contentAlignment = Alignment.Center
                ) {
                    if (match.status == MatchStatus.LIVE || match.status == MatchStatus.FINISHED) {
                        Text(
                            text = "${match.scoreHome ?: 0} - ${match.scoreAway ?: 0}",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black,
                            color = if (match.status == MatchStatus.LIVE) TvLiveGreen else Color.White
                        )
                    } else {
                        Text(
                            text = "VS",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = TvGoldAccent
                        )
                    }
                }

                // Away Team
                Row(
                    modifier = Modifier.weight(1f),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = match.awayTeam,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        textAlign = TextAlign.End
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    TeamLogoImage(url = match.awayLogoUrl, teamName = match.awayTeam)
                }
            }
        }
    }
}

@Composable
private fun TeamLogoImage(url: String, teamName: String) {
    Box(
        modifier = Modifier
            .size(24.dp)
            .clip(CircleShape)
            .background(Color(0x33FFFFFF)),
        contentAlignment = Alignment.Center
    ) {
        AsyncImage(
            model = url,
            contentDescription = teamName,
            modifier = Modifier.size(20.dp),
            contentScale = ContentScale.Fit
        )
    }
}

@Composable
private fun MatchStatusBadge(status: MatchStatus, minute: String?) {
    val (bgColor, textColor, label) = when (status) {
        MatchStatus.LIVE -> Triple(TvLiveGreen.copy(alpha = 0.25f), TvLiveGreen, minute ?: "LIVE")
        MatchStatus.FINISHED -> Triple(Color(0x33EF4444), Color(0xFFEF4444), "Selesai")
        MatchStatus.UPCOMING -> Triple(Color(0x3338BDF8), Color(0xFF38BDF8), "Akan Main")
        MatchStatus.POSTPONED -> Triple(Color(0x33EAB308), Color(0xFFEAB308), "Ditunda")
    }

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(bgColor)
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text = label,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = textColor
        )
    }
}
