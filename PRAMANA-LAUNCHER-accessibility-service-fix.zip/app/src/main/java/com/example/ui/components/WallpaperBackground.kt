package com.example.ui.components

import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import coil.compose.AsyncImage
import com.example.R
import com.example.data.model.ScaleMode
import com.example.data.model.WallpaperConfig
import com.example.data.model.WallpaperType

@Composable
fun WallpaperBackground(
    wallpaperConfig: WallpaperConfig,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val contentScale = when (wallpaperConfig.scaleMode) {
        ScaleMode.CENTER_CROP -> ContentScale.Crop
        ScaleMode.FIT -> ContentScale.Fit
        ScaleMode.STRETCH -> ContentScale.FillBounds
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF070B14))
    ) {
        when (wallpaperConfig.type) {
            WallpaperType.CUSTOM_URI -> {
                if (!wallpaperConfig.customUriString.isNullOrBlank()) {
                    AsyncImage(
                        model = Uri.parse(wallpaperConfig.customUriString),
                        contentDescription = "Wallpaper Kustom",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = contentScale
                    )
                } else {
                    DefaultPresetWallpaper(presetId = wallpaperConfig.presetId, contentScale = contentScale)
                }
            }

            WallpaperType.PRESET -> {
                DefaultPresetWallpaper(presetId = wallpaperConfig.presetId, contentScale = contentScale)
            }
        }

        // Ambient glassmorphism gradient vignette overlay for optimal TV readability
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color(0x88050914),
                            Color(0x44050914),
                            Color(0x99050914)
                        )
                    )
                )
        )
    }
}

@Composable
private fun DefaultPresetWallpaper(
    presetId: String,
    contentScale: ContentScale
) {
    when (presetId) {
        "nebula_aurora" -> {
            Image(
                painter = painterResource(id = R.drawable.wallpaper_nebula_aurora),
                contentDescription = "Nebula Aurora Wallpaper",
                modifier = Modifier.fillMaxSize(),
                contentScale = contentScale
            )
        }
        "dark_slate" -> {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                Color(0xFF1E293B),
                                Color(0xFF0F172A),
                                Color(0xFF020617)
                            )
                        )
                    )
            )
        }
        else -> { // "neon_cyber" default
            Image(
                painter = painterResource(id = R.drawable.wallpaper_neon_cyber),
                contentDescription = "Neon Cyber Wallpaper",
                modifier = Modifier.fillMaxSize(),
                contentScale = contentScale
            )
        }
    }
}
