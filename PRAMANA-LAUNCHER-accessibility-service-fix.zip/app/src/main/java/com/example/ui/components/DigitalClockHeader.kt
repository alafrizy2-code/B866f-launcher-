package com.example.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.TvCyanPrimary
import com.example.ui.theme.TvGoldAccent
import com.example.ui.theme.TvTextPrimary
import com.example.ui.theme.TvTextSecondary
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

@Composable
fun DigitalClockHeader(
    is24Hour: Boolean = true,
    modifier: Modifier = Modifier
) {
    var currentTimeMillis by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(Unit) {
        while (true) {
            currentTimeMillis = System.currentTimeMillis()
            delay(1000L)
        }
    }

    val timePattern = if (is24Hour) "HH:mm:ss" else "hh:mm:ss a"
    val timeFormat = remember(is24Hour) {
        SimpleDateFormat(timePattern, Locale("id", "ID")).apply {
            timeZone = TimeZone.getTimeZone("Asia/Jakarta")
        }
    }

    val dateFormat = remember {
        SimpleDateFormat("EEEE, dd MMMM yyyy", Locale("id", "ID")).apply {
            timeZone = TimeZone.getTimeZone("Asia/Jakarta")
        }
    }

    val date = remember(currentTimeMillis) { Date(currentTimeMillis) }
    val formattedTime = remember(currentTimeMillis, is24Hour) { timeFormat.format(date) }
    val formattedDate = remember(currentTimeMillis) { dateFormat.format(date) }

    Column(modifier = modifier) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "B866F",
                fontSize = 24.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.5.sp,
                color = TvCyanPrimary
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "LAUNCHER",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp,
                color = TvTextPrimary
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = "• B866F EDITION",
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                letterSpacing = 1.sp,
                color = TvGoldAccent
            )
        }

        Spacer(modifier = Modifier.height(4.dp))

        Row(verticalAlignment = Alignment.Bottom) {
            Text(
                text = formattedTime,
                fontSize = 22.sp,
                fontWeight = FontWeight.SemiBold,
                fontFamily = FontFamily.Monospace,
                color = Color.White
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "WIB",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = TvCyanPrimary
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = "—",
                fontSize = 14.sp,
                color = TvTextSecondary
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = formattedDate,
                fontSize = 14.sp,
                fontWeight = FontWeight.Normal,
                color = TvTextSecondary
            )
        }
    }
}
