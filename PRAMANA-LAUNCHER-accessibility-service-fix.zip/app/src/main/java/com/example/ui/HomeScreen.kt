package com.example.ui

import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.ui.components.AnalogClockWidget
import com.example.ui.components.AppDock
import com.example.ui.components.DigitalClockHeader
import com.example.ui.components.FootballScheduleWidget
import com.example.ui.components.SidebarSettings
import com.example.ui.components.TopUtilityBar
import com.example.ui.components.WallpaperBackground

@Composable
fun HomeScreen(
    viewModel: LauncherViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    val preferences by viewModel.preferences.collectAsState()
    val wallpaperConfig by viewModel.wallpaperConfig.collectAsState()
    val installedApps by viewModel.installedApps.collectAsState()
    val fixtures by viewModel.fixtures.collectAsState()
    val isLoadingFixtures by viewModel.isLoadingFixtures.collectAsState()
    val isSidebarOpen by viewModel.isSidebarOpen.collectAsState()
    val selectedLeagueCode by viewModel.selectedLeagueCode.collectAsState()

    // Storage Access Framework (SAF) custom wallpaper picker
    val wallpaperPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                // Persist read permission across reboots
                val takeFlags: Int = Intent.FLAG_GRANT_READ_URI_PERMISSION
                context.contentResolver.takePersistableUriPermission(uri, takeFlags)
            } catch (_: Exception) {}
            viewModel.setCustomWallpaperUri(uri.toString())
            Toast.makeText(context, "Wallpaper kustom berhasil diterapkan", Toast.LENGTH_SHORT).show()
        }
    }

    // Remote Control Back button handling: Close sidebar if open, otherwise stay on launcher
    BackHandler(enabled = true) {
        if (isSidebarOpen) {
            viewModel.closeSidebar()
        } else {
            // TV Launcher home screen: BACK does not exit
        }
    }

    // Refresh apps on resume
    LaunchedEffect(Unit) {
        viewModel.loadInstalledApps()
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .onPreviewKeyEvent { event ->
                // Support Android TV Remote MENU key to open/close sidebar
                if (event.key == Key.Menu) {
                    viewModel.toggleSidebar()
                    true
                } else {
                    false
                }
            }
    ) {
        // 1. Fullscreen Wallpaper Background
        WallpaperBackground(
            wallpaperConfig = wallpaperConfig,
            modifier = Modifier.fillMaxSize()
        )

        // 2. Main TV Dashboard Grid Layout
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 18.dp, start = 24.dp, end = 24.dp, bottom = 0.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Bar: Header (Left) + Utility Icons (Right)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                DigitalClockHeader(
                    is24Hour = preferences.is24HourFormat
                )

                TopUtilityBar(
                    onOpenSidebar = { viewModel.openSidebar() }
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Center Workspace: Football Schedule Widget (Left) + Analog Clock (Center)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Left: Football Schedule Widget
                if (preferences.showFootballWidget) {
                    FootballScheduleWidget(
                        leagues = viewModel.supportedLeagues,
                        selectedLeagueCode = selectedLeagueCode,
                        fixtures = fixtures,
                        isLoading = isLoadingFixtures,
                        onSelectLeague = { viewModel.selectLeague(it) },
                        onRefresh = { viewModel.loadFixtures() },
                        modifier = Modifier
                            .width(370.dp)
                            .padding(end = 16.dp)
                    )
                }

                // Center: Classic Glass Analog Clock Widget
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    if (preferences.showAnalogClock) {
                        AnalogClockWidget(
                            size = 190.dp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Bottom: Single Row App Dock
            AppDock(
                apps = installedApps,
                dockScale = preferences.dockScale,
                onLaunchApp = { app ->
                    val launched = viewModel.launchApp(app)
                    if (!launched) {
                        Toast.makeText(context, "Tidak dapat membuka ${app.label}", Toast.LENGTH_SHORT).show()
                    }
                },
                onMoveApp = { from, to -> viewModel.moveApp(from, to) },
                onHideApp = { app -> viewModel.toggleHideApp(app) },
                modifier = Modifier.fillMaxWidth()
            )
        }

        // 3. Settings Sidebar Sliding Drawer from Right
        SidebarSettings(
            isOpen = isSidebarOpen,
            onClose = { viewModel.closeSidebar() },
            preferences = preferences,
            onUpdatePreferences = { transform -> viewModel.updatePreferences(transform) },
            wallpaperConfig = wallpaperConfig,
            onSelectPresetWallpaper = { presetId -> viewModel.selectPresetWallpaper(presetId) },
            onPickCustomWallpaper = {
                wallpaperPickerLauncher.launch(
                    arrayOf("image/jpeg", "image/png", "image/webp")
                )
            },
            onChangeScaleMode = { scaleMode -> viewModel.setWallpaperScaleMode(scaleMode) },
            installedApps = installedApps,
            onUnhideApp = { app -> viewModel.toggleHideApp(app) },
            onResetDockOrder = { viewModel.resetDockOrder() },
            modifier = Modifier.align(Alignment.CenterEnd)
        )
    }
}
