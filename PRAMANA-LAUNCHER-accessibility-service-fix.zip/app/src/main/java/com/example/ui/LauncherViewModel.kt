package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.InstalledAppsManager
import com.example.data.local.LauncherPreferencesManager
import com.example.data.model.AppItem
import com.example.data.model.LauncherPreferences
import com.example.data.model.LeagueInfo
import com.example.data.model.MatchFixture
import com.example.data.model.ScaleMode
import com.example.data.model.WallpaperConfig
import com.example.data.model.WallpaperType
import com.example.data.remote.FootballRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class LauncherViewModel(application: Application) : AndroidViewModel(application) {

    private val prefsManager = LauncherPreferencesManager(application)
    private val appsManager = InstalledAppsManager(application)
    private val footballRepo = FootballRepository(application)

    val supportedLeagues: List<LeagueInfo> = footballRepo.supportedLeagues

    val preferences: StateFlow<LauncherPreferences> = prefsManager.preferencesFlow
    val wallpaperConfig: StateFlow<WallpaperConfig> = prefsManager.wallpaperFlow

    private val _installedApps = MutableStateFlow<List<AppItem>>(emptyList())
    val installedApps: StateFlow<List<AppItem>> = _installedApps.asStateFlow()

    private val _fixtures = MutableStateFlow<List<MatchFixture>>(emptyList())
    val fixtures: StateFlow<List<MatchFixture>> = _fixtures.asStateFlow()

    private val _isLoadingFixtures = MutableStateFlow(false)
    val isLoadingFixtures: StateFlow<Boolean> = _isLoadingFixtures.asStateFlow()

    private val _isSidebarOpen = MutableStateFlow(false)
    val isSidebarOpen: StateFlow<Boolean> = _isSidebarOpen.asStateFlow()

    private val _selectedLeagueCode = MutableStateFlow(preferences.value.selectedLeagueCode)
    val selectedLeagueCode: StateFlow<String> = _selectedLeagueCode.asStateFlow()

    private var autoRefreshJob: Job? = null

    init {
        loadInstalledApps()
        loadFixtures(_selectedLeagueCode.value)
        startPeriodicRefresh()

        // Observe preference changes
        viewModelScope.launch {
            prefsManager.hiddenAppsFlow.collectLatest {
                loadInstalledApps()
            }
        }
        viewModelScope.launch {
            prefsManager.dockOrderFlow.collectLatest {
                loadInstalledApps()
            }
        }
    }

    fun loadInstalledApps() {
        viewModelScope.launch {
            val order = prefsManager.loadDockOrder()
            val hidden = prefsManager.loadHiddenApps()
            _installedApps.value = appsManager.getInstalledApps(order, hidden)
        }
    }

    fun launchApp(app: AppItem): Boolean {
        return appsManager.launchApp(app)
    }

    fun moveApp(fromIndex: Int, toIndex: Int) {
        viewModelScope.launch {
            val currentVisible = _installedApps.value.filter { !it.isHidden }.toMutableList()
            if (fromIndex in currentVisible.indices && toIndex in currentVisible.indices) {
                val item = currentVisible.removeAt(fromIndex)
                currentVisible.add(toIndex, item)

                val newDockOrder = currentVisible.map { it.packageName }
                prefsManager.saveDockOrder(newDockOrder)
                loadInstalledApps()
            }
        }
    }

    fun toggleHideApp(app: AppItem) {
        viewModelScope.launch {
            prefsManager.toggleAppHidden(app.packageName)
            loadInstalledApps()
        }
    }

    fun unhideAllApps() {
        viewModelScope.launch {
            prefsManager.unhideAllApps()
            loadInstalledApps()
        }
    }

    fun resetDockOrder() {
        viewModelScope.launch {
            prefsManager.saveDockOrder(emptyList())
            loadInstalledApps()
        }
    }

    fun selectLeague(code: String) {
        _selectedLeagueCode.value = code
        prefsManager.updatePreferences { it.copy(selectedLeagueCode = code) }
        loadFixtures(code)
    }

    fun loadFixtures(leagueCode: String = _selectedLeagueCode.value) {
        viewModelScope.launch {
            _isLoadingFixtures.value = true
            try {
                val data = footballRepo.getFixturesForLeague(
                    leagueCode = leagueCode,
                    apiKey = preferences.value.footballApiKey
                )
                _fixtures.value = data
            } catch (_: Exception) {
                // Keep cached data
            } finally {
                _isLoadingFixtures.value = false
            }
        }
    }

    private fun startPeriodicRefresh() {
        autoRefreshJob?.cancel()
        autoRefreshJob = viewModelScope.launch {
            while (true) {
                delay(60_000L) // Refresh every 1 minute if auto-refresh is active
                if (preferences.value.autoRefreshFootball) {
                    loadFixtures(_selectedLeagueCode.value)
                }
            }
        }
    }

    fun selectPresetWallpaper(presetId: String) {
        prefsManager.saveWallpaperConfig(
            wallpaperConfig.value.copy(
                type = WallpaperType.PRESET,
                presetId = presetId
            )
        )
    }

    fun setCustomWallpaperUri(uriString: String) {
        prefsManager.saveWallpaperConfig(
            wallpaperConfig.value.copy(
                type = WallpaperType.CUSTOM_URI,
                customUriString = uriString
            )
        )
    }

    fun setWallpaperScaleMode(mode: ScaleMode) {
        prefsManager.saveWallpaperConfig(
            wallpaperConfig.value.copy(scaleMode = mode)
        )
    }

    fun updatePreferences(transform: (LauncherPreferences) -> LauncherPreferences) {
        prefsManager.updatePreferences(transform)
    }

    fun openSidebar() {
        _isSidebarOpen.value = true
    }

    fun closeSidebar() {
        _isSidebarOpen.value = false
    }

    fun toggleSidebar() {
        _isSidebarOpen.value = !_isSidebarOpen.value
    }
}
