package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.Usb
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.TvCardBg
import com.example.ui.theme.TvCyanPrimary
import com.example.ui.theme.TvGlassSurface
import com.example.ui.theme.TvGoldAccent
import com.example.ui.theme.TvTextPrimary
import com.example.ui.theme.TvTextSecondary
import java.io.File
import java.net.Inet4Address
import java.net.NetworkInterface

@Composable
fun TopUtilityBar(
    onOpenSidebar: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var showNetworkDialog by remember { mutableStateOf(false) }
    var showStorageDialog by remember { mutableStateOf(false) }
    var isMuted by remember { mutableStateOf(false) }

    val networkInfo = remember(showNetworkDialog) { getNetworkInfo(context) }
    val storageInfo = remember(showStorageDialog) { getStorageInfo() }

    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // 1. Wi-Fi / Jaringan
        UtilityIconButton(
            icon = if (networkInfo.isConnected) Icons.Default.Wifi else Icons.Default.WifiOff,
            contentDesc = "Jaringan & Wi-Fi",
            tint = if (networkInfo.isConnected) TvCyanPrimary else Color.Gray,
            onClick = { showNetworkDialog = true }
        )

        // 2. USB / Penyimpanan
        UtilityIconButton(
            icon = Icons.Default.Usb,
            contentDesc = "Penyimpanan & USB",
            tint = TvGoldAccent,
            onClick = { showStorageDialog = true }
        )

        // 3. Audio / Mode Suara
        UtilityIconButton(
            icon = if (isMuted) Icons.Default.NotificationsOff else Icons.Default.Notifications,
            contentDesc = "Mode Notifikasi",
            tint = if (isMuted) Color.LightGray else TvCyanPrimary,
            onClick = { isMuted = !isMuted }
        )

        // 4. Pengaturan Launcher (Buka Sidebar)
        UtilityIconButton(
            icon = Icons.Default.Settings,
            contentDesc = "Pengaturan Launcher",
            tint = TvCyanPrimary,
            onClick = onOpenSidebar
        )

        // 5. Pengaturan Sistem Android TV
        UtilityIconButton(
            icon = Icons.Default.Tv,
            contentDesc = "Pengaturan Sistem Android TV",
            tint = Color(0xFF60A5FA),
            onClick = {
                try {
                    val intent = Intent(Settings.ACTION_SETTINGS).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(intent)
                } catch (_: Exception) {
                    // Fallback
                }
            }
        )
    }

    // Network Info Dialog
    if (showNetworkDialog) {
        AlertDialog(
            onDismissRequest = { showNetworkDialog = false },
            containerColor = TvCardBg,
            shape = RoundedCornerShape(16.dp),
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Wifi, contentDescription = null, tint = TvCyanPrimary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Status Jaringan TV", color = TvTextPrimary, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column {
                    Text("Tipe Koneksi: ${networkInfo.type}", color = TvTextSecondary, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Alamat IP: ${networkInfo.ipAddress}", color = TvTextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("SSID / Nama: ${networkInfo.ssid}", color = TvTextSecondary, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Status Internet: ${if (networkInfo.hasInternet) "Terkoneksi Aktif" else "Terputus"}",
                        color = if (networkInfo.hasInternet) Color(0xFF10B981) else Color(0xFFEF4444),
                        fontWeight = FontWeight.Medium
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showNetworkDialog = false
                        try {
                            context.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            })
                        } catch (_: Exception) {}
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = TvCyanPrimary)
                ) {
                    Text("Buka Pengaturan Wi-Fi", color = Color.Black)
                }
            },
            dismissButton = {
                TextButton(onClick = { showNetworkDialog = false }) {
                    Text("Tutup", color = TvTextSecondary)
                }
            }
        )
    }

    // Storage Info Dialog
    if (showStorageDialog) {
        AlertDialog(
            onDismissRequest = { showStorageDialog = false },
            containerColor = TvCardBg,
            shape = RoundedCornerShape(16.dp),
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Usb, contentDescription = null, tint = TvGoldAccent)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Status Penyimpanan & USB", color = TvTextPrimary, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column {
                    Text("Penyimpanan Internal:", color = TvTextSecondary, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(2.dp))
                    Text("${storageInfo.availableGb} GB bebas dari ${storageInfo.totalGb} GB",
                        color = TvTextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("Slot USB / External:", color = TvTextSecondary, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(storageInfo.usbStatus, color = TvGoldAccent, fontWeight = FontWeight.Medium)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showStorageDialog = false
                        try {
                            context.startActivity(Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            })
                        } catch (_: Exception) {}
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = TvGoldAccent)
                ) {
                    Text("Pengaturan Storage", color = Color.Black)
                }
            },
            dismissButton = {
                TextButton(onClick = { showStorageDialog = false }) {
                    Text("Tutup", color = TvTextSecondary)
                }
            }
        )
    }
}

@Composable
private fun UtilityIconButton(
    icon: ImageVector,
    contentDesc: String,
    tint: Color,
    onClick: () -> Unit
) {
    TvFocusableCard(
        onClick = onClick,
        shape = CircleShape,
        backgroundColor = TvGlassSurface,
        focusedScale = 1.15f,
        modifier = Modifier.size(42.dp)
    ) { isFocused ->
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = contentDesc,
                tint = if (isFocused) Color.White else tint,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

data class NetworkInfoDetails(
    val isConnected: Boolean,
    val type: String,
    val ipAddress: String,
    val ssid: String,
    val hasInternet: Boolean
)

internal fun getNetworkInfo(context: Context): NetworkInfoDetails {
    val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
    val activeNet = cm?.activeNetwork
    val caps = cm?.getNetworkCapabilities(activeNet)

    val isWifi = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
    val isEthernet = caps?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true
    val isConnected = caps != null
    val hasInternet = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true

    var ip = "127.0.0.1"
    try {
        val interfaces = NetworkInterface.getNetworkInterfaces()
        for (nInterface in interfaces) {
            val addresses = nInterface.inetAddresses
            for (addr in addresses) {
                if (!addr.isLoopbackAddress && addr is Inet4Address) {
                    ip = addr.hostAddress ?: "127.0.0.1"
                    break
                }
            }
        }
    } catch (_: Exception) {}

    val ssid = if (isWifi) {
        val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        val s = wm?.connectionInfo?.ssid?.replace("\"", "") ?: "Wi-Fi Aktif"
        if (s == "<unknown ssid>" || s.isBlank()) "Wi-Fi TV" else s
    } else if (isEthernet) {
        "Ethernet (Kabel LAN)"
    } else {
        "Tidak Terhubung"
    }

    val type = when {
        isEthernet -> "Ethernet (LAN)"
        isWifi -> "Wi-Fi Nirkabel"
        else -> "Tidak Ada"
    }

    return NetworkInfoDetails(isConnected, type, ip, ssid, hasInternet)
}

data class StorageInfoDetails(
    val availableGb: String,
    val totalGb: String,
    val usbStatus: String
)

internal fun getStorageInfo(): StorageInfoDetails {
    return try {
        val stat = StatFs(Environment.getDataDirectory().path)
        val blockSize = stat.blockSizeLong
        val totalBytes = stat.blockCountLong * blockSize
        val availableBytes = stat.availableBlocksLong * blockSize

        val totalGb = String.format("%.1f", totalBytes / (1024.0 * 1024.0 * 1024.0))
        val availGb = String.format("%.1f", availableBytes / (1024.0 * 1024.0 * 1024.0))

        val usbDir = File("/storage")
        val usbMounted = usbDir.listFiles()?.any { it.name != "emulated" && it.name != "self" && it.canRead() } == true

        StorageInfoDetails(
            availableGb = availGb,
            totalGb = totalGb,
            usbStatus = if (usbMounted) "Flash Drive / USB Terdeteksi" else "Siap Digunakan (Tidak ada USB tertancap)"
        )
    } catch (_: Exception) {
        StorageInfoDetails("3.8", "8.0", "Siap Digunakan")
    }
}
