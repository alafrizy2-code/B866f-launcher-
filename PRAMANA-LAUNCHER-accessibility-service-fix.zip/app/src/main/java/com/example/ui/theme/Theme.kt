package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val TvDarkColorScheme = darkColorScheme(
    primary = TvCyanPrimary,
    onPrimary = Color(0xFF001E2B),
    primaryContainer = Color(0xFF004D65),
    onPrimaryContainer = Color(0xFFBCE9FF),
    secondary = TvGoldAccent,
    onSecondary = Color(0xFF261900),
    secondaryContainer = Color(0xFF432C00),
    onSecondaryContainer = Color(0xFFFFDEA3),
    background = TvDarkBg,
    onBackground = TvTextPrimary,
    surface = TvGlassSurface,
    onSurface = TvTextPrimary,
    surfaceVariant = TvGlassSurfaceLight,
    onSurfaceVariant = TvTextSecondary,
    outline = TvGlassBorder
)

@Composable
fun PramanaLauncherTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = TvDarkColorScheme,
        typography = Typography,
        content = content
    )
}
