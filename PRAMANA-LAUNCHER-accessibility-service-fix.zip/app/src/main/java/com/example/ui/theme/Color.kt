package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary TV Glassmorphism & Cyber Palette
val TvCyanPrimary = Color(0xFF00E5FF)
val TvCyanVariant = Color(0xFF00B0FF)
val TvGoldAccent = Color(0xFFFFB703)
val TvAmberGlow = Color(0xFFF59E0B)

val TvDarkBg = Color(0xFF0A0F1D)
val TvGlassSurface = Color(0x990F172A)
val TvGlassSurfaceLight = Color(0x661E293B)
val TvGlassBorder = Color(0x4038BDF8)
val TvFocusBorder = Color(0xFF00E5FF)
val TvCardBg = Color(0xB30F172A)

// Text Colors
val TvTextPrimary = Color(0xFFF8FAFC)
val TvTextSecondary = Color(0xFF94A3B8)
val TvTextMuted = Color(0xFF64748B)

// Status Colors
val TvLiveGreen = Color(0xFF10B981)
val TvFinishedRed = Color(0xFFEF4444)
val TvUpcomingBlue = Color(0xFF3B82F6)
