package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.AppItem
import com.example.ui.theme.TvCardBg
import com.example.ui.theme.TvCyanPrimary
import com.example.ui.theme.TvGlassBorder
import com.example.ui.theme.TvGlassSurface
import com.example.ui.theme.TvGoldAccent
import com.example.ui.theme.TvTextPrimary
import com.example.ui.theme.TvTextSecondary

@Composable
fun AppDock(
    apps: List<AppItem>,
    dockScale: Float = 1.0f,
    onLaunchApp: (AppItem) -> Unit,
    onMoveApp: (fromIndex: Int, toIndex: Int) -> Unit,
    onHideApp: (AppItem) -> Unit,
    modifier: Modifier = Modifier
) {
    var isEditMode by remember { mutableStateOf(false) }
    var selectedAppForAction by remember { mutableStateOf<Pair<Int, AppItem>?>(null) }

    val visibleApps = remember(apps) { apps.filter { !it.isHidden } }

    val baseCardWidth = (88 * dockScale).dp
    val baseCardHeight = (88 * dockScale).dp
    val baseIconSize = (44 * dockScale).dp

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
            .background(TvGlassSurface.copy(alpha = 0.85f))
            .border(1.dp, TvGlassBorder, RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        // Dock Header / Mode Edit Toggle
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Apps,
                    contentDescription = null,
                    tint = TvCyanPrimary,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isEditMode) "MODE EDIT DOCK — PILIH APLIKASI UNTUK PINDAH/SEMBUNYIKAN" else "APLIKASI FAVORIT",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    color = if (isEditMode) TvGoldAccent else TvTextSecondary
                )
            }

            TvFocusableCard(
                onClick = { isEditMode = !isEditMode },
                shape = RoundedCornerShape(8.dp),
                backgroundColor = if (isEditMode) TvGoldAccent.copy(alpha = 0.2f) else TvGlassBorder.copy(alpha = 0.2f),
                focusedBorderColor = if (isEditMode) TvGoldAccent else TvCyanPrimary,
                focusedScale = 1.08f,
                elevation = 0.dp
            ) { isFocused ->
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (isEditMode) Icons.Default.Check else Icons.Default.Edit,
                        contentDescription = null,
                        tint = if (isEditMode) TvGoldAccent else if (isFocused) Color.White else TvTextSecondary,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isEditMode) "Selesai" else "Edit Urutan",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = if (isEditMode) TvGoldAccent else if (isFocused) Color.White else TvTextSecondary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Horizontal Row of Apps
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp)
        ) {
            itemsIndexed(visibleApps) { index, app ->
                AppDockItemCard(
                    app = app,
                    index = index,
                    isEditMode = isEditMode,
                    cardWidth = baseCardWidth,
                    cardHeight = baseCardHeight,
                    iconSize = baseIconSize,
                    onClick = {
                        if (isEditMode) {
                            selectedAppForAction = Pair(index, app)
                        } else {
                            onLaunchApp(app)
                        }
                    }
                )
            }
        }
    }

    // App Action Dialog in Edit Mode (Move Left, Move Right, Hide)
    selectedAppForAction?.let { (index, app) ->
        AlertDialog(
            onDismissRequest = { selectedAppForAction = null },
            containerColor = TvCardBg,
            shape = RoundedCornerShape(16.dp),
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color(0x22FFFFFF)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (app.iconDrawable != null) {
                            AsyncImage(
                                model = app.iconDrawable,
                                contentDescription = app.label,
                                modifier = Modifier.size(30.dp)
                            )
                        } else {
                            Icon(Icons.Default.Apps, contentDescription = null, tint = TvCyanPrimary)
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = app.label,
                        color = TvTextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }
            },
            text = {
                Column {
                    Text(
                        text = "Atur posisi atau tampilkan aplikasi di dock:",
                        color = TvTextSecondary,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                if (index > 0) {
                                    onMoveApp(index, index - 1)
                                    selectedAppForAction = Pair(index - 1, app)
                                }
                            },
                            enabled = index > 0,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0x3338BDF8)),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Geser Kiri", fontSize = 12.sp)
                        }

                        Button(
                            onClick = {
                                if (index < visibleApps.size - 1) {
                                    onMoveApp(index, index + 1)
                                    selectedAppForAction = Pair(index + 1, app)
                                }
                            },
                            enabled = index < visibleApps.size - 1,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0x3338BDF8)),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Geser Kanan", fontSize = 12.sp)
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = {
                            onHideApp(app)
                            selectedAppForAction = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0x33EF4444)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.VisibilityOff, contentDescription = null, tint = Color(0xFFEF4444), modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Sembunyikan dari Dock", color = Color(0xFFEF4444), fontSize = 13.sp)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { selectedAppForAction = null }) {
                    Text("Tutup", color = TvCyanPrimary)
                }
            }
        )
    }
}

@Composable
private fun AppDockItemCard(
    app: AppItem,
    index: Int,
    isEditMode: Boolean,
    cardWidth: androidx.compose.ui.unit.Dp,
    cardHeight: androidx.compose.ui.unit.Dp,
    iconSize: androidx.compose.ui.unit.Dp,
    onClick: () -> Unit
) {
    TvFocusableCard(
        onClick = onClick,
        shape = RoundedCornerShape(14.dp),
        backgroundColor = if (isEditMode) Color(0x66292524) else Color(0x440F172A),
        focusedBorderColor = if (isEditMode) TvGoldAccent else TvCyanPrimary,
        unfocusedBorderColor = if (isEditMode) TvGoldAccent.copy(alpha = 0.4f) else TvGlassBorder,
        focusedScale = 1.14f,
        modifier = Modifier.size(width = cardWidth, height = cardHeight)
    ) { isFocused ->
        Column(
            modifier = Modifier
                .size(width = cardWidth, height = cardHeight)
                .padding(horizontal = 4.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(iconSize)
                    .clip(CircleShape)
                    .background(Color(0x22FFFFFF)),
                contentAlignment = Alignment.Center
            ) {
                if (app.iconDrawable != null) {
                    AsyncImage(
                        model = app.iconDrawable,
                        contentDescription = app.label,
                        modifier = Modifier.size(iconSize * 0.82f),
                        contentScale = ContentScale.Fit
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.Apps,
                        contentDescription = app.label,
                        tint = if (isFocused) TvCyanPrimary else Color.White,
                        modifier = Modifier.size(iconSize * 0.65f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = app.label,
                fontSize = 11.sp,
                fontWeight = if (isFocused) FontWeight.Bold else FontWeight.Medium,
                color = if (isFocused) Color.White else TvTextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center
            )
        }
    }
}
