package com.example.ui.components

import android.graphics.Paint
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.TvCyanPrimary
import com.example.ui.theme.TvGoldAccent
import kotlinx.coroutines.delay
import java.util.Calendar
import java.util.TimeZone
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun AnalogClockWidget(
    size: Dp = 190.dp,
    modifier: Modifier = Modifier
) {
    var currentTimeMillis by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(Unit) {
        while (true) {
            currentTimeMillis = System.currentTimeMillis()
            delay(100L) // 10fps for smooth seconds
        }
    }

    val calendar = remember(currentTimeMillis) {
        Calendar.getInstance(TimeZone.getTimeZone("Asia/Jakarta")).apply {
            timeInMillis = currentTimeMillis
        }
    }

    val hours = calendar.get(Calendar.HOUR)
    val minutes = calendar.get(Calendar.MINUTE)
    val seconds = calendar.get(Calendar.SECOND)
    val millis = calendar.get(Calendar.MILLISECOND)

    // Fractional values for smooth hand rotation
    val secondFraction = seconds + (millis / 1000f)
    val minuteFraction = minutes + (secondFraction / 60f)
    val hourFraction = (hours % 12) + (minuteFraction / 60f)

    val hourAngle = (hourFraction * 30f) - 90f // 360 / 12 = 30 deg per hour
    val minuteAngle = (minuteFraction * 6f) - 90f // 360 / 60 = 6 deg per minute
    val secondAngle = (secondFraction * 6f) - 90f

    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(size)) {
            val center = Offset(this.size.width / 2f, this.size.height / 2f)
            val radius = (this.size.minDimension / 2f) - 6.dp.toPx()

            // 1. Dial background glass circle
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0x330F172A),
                        Color(0x770A0F1D)
                    ),
                    center = center,
                    radius = radius
                ),
                radius = radius,
                center = center
            )

            // Outer metallic/glass bezel
            drawCircle(
                brush = Brush.sweepGradient(
                    colors = listOf(
                        TvCyanPrimary.copy(alpha = 0.6f),
                        TvGoldAccent.copy(alpha = 0.4f),
                        Color(0x44FFFFFF),
                        TvCyanPrimary.copy(alpha = 0.6f)
                    ),
                    center = center
                ),
                radius = radius,
                center = center,
                style = Stroke(width = 2.5.dp.toPx())
            )

            // 2. Hour markers & numerals 1-12
            val paint = Paint().apply {
                color = android.graphics.Color.WHITE
                textSize = 13.dp.toPx()
                textAlign = Paint.Align.CENTER
                isAntiAlias = true
                typeface = android.graphics.Typeface.create(
                    android.graphics.Typeface.DEFAULT,
                    android.graphics.Typeface.BOLD
                )
                setShadowLayer(4f, 0f, 2f, android.graphics.Color.BLACK)
            }

            for (i in 1..12) {
                val angleDeg = (i * 30.0) - 90.0
                val angleRad = Math.toRadians(angleDeg)

                // Tick line
                val outerTickRadius = radius - 4.dp.toPx()
                val innerTickRadius = radius - (if (i % 3 == 0) 12.dp.toPx() else 8.dp.toPx())
                val tickStart = Offset(
                    x = (center.x + innerTickRadius * cos(angleRad)).toFloat(),
                    y = (center.y + innerTickRadius * sin(angleRad)).toFloat()
                )
                val tickEnd = Offset(
                    x = (center.x + outerTickRadius * cos(angleRad)).toFloat(),
                    y = (center.y + outerTickRadius * sin(angleRad)).toFloat()
                )

                drawLine(
                    color = if (i % 3 == 0) TvCyanPrimary else Color(0x99FFFFFF),
                    start = tickStart,
                    end = tickEnd,
                    strokeWidth = if (i % 3 == 0) 2.dp.toPx() else 1.dp.toPx(),
                    cap = StrokeCap.Round
                )

                // Numeral text
                val numRadius = radius - 20.dp.toPx()
                val numX = (center.x + numRadius * cos(angleRad)).toFloat()
                val numY = (center.y + numRadius * sin(angleRad) + (paint.textSize / 3f)).toFloat()

                drawContext.canvas.nativeCanvas.drawText(
                    i.toString(),
                    numX,
                    numY,
                    paint
                )
            }

            // 3. Hour hand
            val hourLength = radius * 0.50f
            val hourRad = Math.toRadians(hourAngle.toDouble())
            val hourEnd = Offset(
                x = (center.x + hourLength * cos(hourRad)).toFloat(),
                y = (center.y + hourLength * sin(hourRad)).toFloat()
            )
            drawLine(
                color = Color.White,
                start = center,
                end = hourEnd,
                strokeWidth = 4.dp.toPx(),
                cap = StrokeCap.Round
            )

            // 4. Minute hand
            val minuteLength = radius * 0.72f
            val minuteRad = Math.toRadians(minuteAngle.toDouble())
            val minuteEnd = Offset(
                x = (center.x + minuteLength * cos(minuteRad)).toFloat(),
                y = (center.y + minuteLength * sin(minuteRad)).toFloat()
            )
            drawLine(
                color = TvCyanPrimary,
                start = center,
                end = minuteEnd,
                strokeWidth = 2.5.dp.toPx(),
                cap = StrokeCap.Round
            )

            // 5. Second hand (glowing cyan / amber accent)
            val secondLength = radius * 0.85f
            val secondRad = Math.toRadians(secondAngle.toDouble())
            val secondEnd = Offset(
                x = (center.x + secondLength * cos(secondRad)).toFloat(),
                y = (center.y + secondLength * sin(secondRad)).toFloat()
            )
            // Counter-weight tail
            val tailLength = radius * 0.18f
            val tailEnd = Offset(
                x = (center.x - tailLength * cos(secondRad)).toFloat(),
                y = (center.y - tailLength * sin(secondRad)).toFloat()
            )
            drawLine(
                color = TvGoldAccent,
                start = tailEnd,
                end = secondEnd,
                strokeWidth = 1.5.dp.toPx(),
                cap = StrokeCap.Round
            )

            // Center pivot cap
            drawCircle(
                color = TvGoldAccent,
                radius = 4.5.dp.toPx(),
                center = center
            )
            drawCircle(
                color = Color.White,
                radius = 2.dp.toPx(),
                center = center
            )
        }
    }
}
