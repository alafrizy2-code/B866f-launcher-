package com.example.ui.components

import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings

object DefaultLauncherHelper {

    enum class HomeLauncherStatus(val label: String) {
        IS_DEFAULT("PRAMANA LAUNCHER sudah menjadi Home default"),
        NOT_DEFAULT("Launcher bawaan masih menjadi Home default"),
        UNKNOWN("Status belum dapat diperiksa")
    }

    fun checkLauncherStatus(context: Context): HomeLauncherStatus {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val roleManager = context.getSystemService(Context.ROLE_SERVICE) as? RoleManager
                if (roleManager != null && roleManager.isRoleAvailable(RoleManager.ROLE_HOME)) {
                    val isHeld = roleManager.isRoleHeld(RoleManager.ROLE_HOME)
                    return if (isHeld) HomeLauncherStatus.IS_DEFAULT else HomeLauncherStatus.NOT_DEFAULT
                }
            }

            // Fallback check via PackageManager
            val intent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_HOME)
            }
            val resolveInfo = context.packageManager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
            if (resolveInfo != null) {
                val currentHomePkg = resolveInfo.activityInfo.packageName
                if (currentHomePkg == context.packageName) {
                    HomeLauncherStatus.IS_DEFAULT
                } else if (currentHomePkg == "android" || currentHomePkg.contains("resolver")) {
                    HomeLauncherStatus.NOT_DEFAULT
                } else {
                    HomeLauncherStatus.NOT_DEFAULT
                }
            } else {
                HomeLauncherStatus.UNKNOWN
            }
        } catch (_: Exception) {
            HomeLauncherStatus.UNKNOWN
        }
    }

    fun openDefaultLauncherSettings(context: Context) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val roleManager = context.getSystemService(Context.ROLE_SERVICE) as? RoleManager
                if (roleManager != null && roleManager.isRoleAvailable(RoleManager.ROLE_HOME)) {
                    val roleIntent = roleManager.createRequestRoleIntent(RoleManager.ROLE_HOME)
                    roleIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(roleIntent)
                    return
                }
            }
        } catch (_: Exception) {}

        // Fallback 1: ACTION_HOME_SETTINGS
        try {
            val intent = Intent(Settings.ACTION_HOME_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            return
        } catch (_: Exception) {}

        // Fallback 2: ACTION_MANAGE_DEFAULT_APPS_SETTINGS
        try {
            val intent = Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            return
        } catch (_: Exception) {}

        // Fallback 3: General system settings
        try {
            val intent = Intent(Settings.ACTION_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Exception) {}
    }
}
