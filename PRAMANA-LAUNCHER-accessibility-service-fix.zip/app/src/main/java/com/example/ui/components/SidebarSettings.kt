package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.Wallpaper
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppItem
import com.example.data.model.LauncherPreferences
import com.example.data.model.ScaleMode
import com.example.data.model.WallpaperConfig
import com.example.data.model.WallpaperPreset
import com.example.data.model.WallpaperType
import com.example.ui.theme.TvCardBg
import com.example.ui.theme.TvCyanPrimary
import com.example.ui.theme.TvGlassBorder
import com.example.ui.theme.TvGlassSurface
import com.example.ui.theme.TvGoldAccent
import com.example.ui.theme.TvTextPrimary
import com.example.ui.theme.TvTextSecondary

data class SettingsMenuItem(
    val id: Int,
    val title: String,
    val icon: ImageVector
)

@Composable
fun SidebarSettings(
    isOpen: Boolean,
    onClose: () -> Unit,
    preferences: LauncherPreferences,
    onUpdatePreferences: ((LauncherPreferences) -> LauncherPreferences) -> Unit,
    wallpaperConfig: WallpaperConfig,
    onSelectPresetWallpaper: (String) -> Unit,
    onPickCustomWallpaper: () -> Unit,
    onChangeScaleMode: (ScaleMode) -> Unit,
    installedApps: List<AppItem>,
    onUnhideApp: (AppItem) -> Unit,
    onResetDockOrder: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (isOpen) {
        BackHandler {
            onClose()
        }
    }

    val context = LocalContext.current
    var selectedMenuIndex by remember { mutableIntStateOf(0) }

    val menuItems = remember {
        listOf(
            SettingsMenuItem(0, "Tema & Wallpaper", Icons.Default.Palette),
            SettingsMenuItem(1, "Aplikasi Dock", Icons.Default.Apps),
            SettingsMenuItem(2, "Jaringan & Perangkat", Icons.Default.Router),
            SettingsMenuItem(3, "Widget & Tampilan", Icons.Default.Widgets),
            SettingsMenuItem(4, "Pengaturan Home", Icons.Default.Home),
            SettingsMenuItem(5, "Pengaturan Sistem", Icons.Default.Settings),
            SettingsMenuItem(6, "Tentang Launcher", Icons.Default.Info)
        )
    }

    AnimatedVisibility(
        visible = isOpen,
        enter = slideInHorizontally(initialOffsetX = { it }),
        exit = slideOutHorizontally(targetOffsetX = { it }),
        modifier = modifier
    ) {
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .width(440.dp)
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(
                            Color(0xEE090D1A),
                            Color(0xFA050811)
                        )
                    )
                )
                .border(1.dp, TvGlassBorder, RoundedCornerShape(topStart = 20.dp, bottomStart = 20.dp))
                .padding(16.dp)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Sidebar Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = null,
                            tint = TvCyanPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "PENGATURAN LAUNCHER",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.2.sp,
                            color = TvTextPrimary
                        )
                    }

                    TvFocusableCard(
                        onClick = onClose,
                        shape = CircleShape,
                        backgroundColor = Color(0x33FFFFFF),
                        focusedScale = 1.15f,
                        modifier = Modifier.size(32.dp)
                    ) { isFocused ->
                        Box(
                            modifier = Modifier.size(32.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Tutup Sidebar",
                                tint = if (isFocused) Color.White else TvTextSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Menu Tabs Navigation
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    menuItems.take(4).forEach { item ->
                        val isSelected = selectedMenuIndex == item.id
                        TvFocusableCard(
                            onClick = { selectedMenuIndex = item.id },
                            shape = RoundedCornerShape(8.dp),
                            backgroundColor = if (isSelected) TvCyanPrimary.copy(alpha = 0.2f) else Color(0x22FFFFFF),
                            focusedBorderColor = TvCyanPrimary,
                            unfocusedBorderColor = if (isSelected) TvCyanPrimary else Color(0x22FFFFFF),
                            focusedScale = 1.05f,
                            modifier = Modifier.weight(1f)
                        ) { isFocused ->
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = item.icon,
                                    contentDescription = item.title,
                                    tint = if (isSelected || isFocused) TvCyanPrimary else TvTextSecondary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = item.title.split(" ").first(),
                                    fontSize = 10.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected || isFocused) Color.White else TvTextSecondary
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    menuItems.drop(4).forEach { item ->
                        val isSelected = selectedMenuIndex == item.id
                        TvFocusableCard(
                            onClick = { selectedMenuIndex = item.id },
                            shape = RoundedCornerShape(8.dp),
                            backgroundColor = if (isSelected) TvCyanPrimary.copy(alpha = 0.2f) else Color(0x22FFFFFF),
                            focusedBorderColor = TvCyanPrimary,
                            unfocusedBorderColor = if (isSelected) TvCyanPrimary else Color(0x22FFFFFF),
                            focusedScale = 1.05f,
                            modifier = Modifier.weight(1f)
                        ) { isFocused ->
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = item.icon,
                                    contentDescription = item.title,
                                    tint = if (isSelected || isFocused) TvCyanPrimary else TvTextSecondary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = item.title.split(" ").first(),
                                    fontSize = 10.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected || isFocused) Color.White else TvTextSecondary
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Detail Section Content
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0x33000000))
                        .padding(12.dp)
                ) {
                    when (selectedMenuIndex) {
                        0 -> ThemeWallpaperSection(
                            wallpaperConfig = wallpaperConfig,
                            onSelectPreset = onSelectPresetWallpaper,
                            onPickCustom = onPickCustomWallpaper,
                            onChangeScale = onChangeScaleMode
                        )
                        1 -> AppsDockSection(
                            installedApps = installedApps,
                            onUnhideApp = onUnhideApp,
                            onResetOrder = onResetDockOrder
                        )
                        2 -> NetworkDeviceSection(context = context)
                        3 -> WidgetsDisplaySection(
                            preferences = preferences,
                            onUpdatePreferences = onUpdatePreferences
                        )
                        4 -> HomeSettingsSection(context = context)
                        5 -> SystemSettingsSection(context = context)
                        6 -> AboutSection()
                    }
                }
            }
        }
    }
}

@Composable
private fun ThemeWallpaperSection(
    wallpaperConfig: WallpaperConfig,
    onSelectPreset: (String) -> Unit,
    onPickCustom: () -> Unit,
    onChangeScale: (ScaleMode) -> Unit
) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("PILIHAN WALLPAPER PRESET", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TvCyanPrimary)
            Spacer(modifier = Modifier.height(6.dp))

            val presets = listOf(
                WallpaperPreset("neon_cyber", "Cyber Neon (Default)", "wallpaper_neon_cyber", 0xFF00E5FF),
                WallpaperPreset("nebula_aurora", "Nebula Aurora", "wallpaper_nebula_aurora", 0xFFA855F7),
                WallpaperPreset("dark_slate", "Dark Minimalist Slate", "dark_slate", 0xFF1E293B)
            )

            presets.forEach { preset ->
                val isSelected = wallpaperConfig.type == WallpaperType.PRESET && wallpaperConfig.presetId == preset.id
                TvFocusableCard(
                    onClick = { onSelectPreset(preset.id) },
                    shape = RoundedCornerShape(10.dp),
                    backgroundColor = if (isSelected) TvCyanPrimary.copy(alpha = 0.2f) else Color(0x33FFFFFF),
                    focusedScale = 1.04f,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp)
                ) { isFocused ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(20.dp)
                                    .clip(CircleShape)
                                    .background(Color(preset.previewGradientHex))
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(preset.name, color = Color.White, fontSize = 13.sp)
                        }

                        if (isSelected) {
                            Icon(Icons.Default.Check, contentDescription = null, tint = TvCyanPrimary, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text("WALLPAPER KUSTOM DARI PERANGKAT", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TvCyanPrimary)
            Spacer(modifier = Modifier.height(6.dp))

            TvFocusableCard(
                onClick = onPickCustom,
                shape = RoundedCornerShape(10.dp),
                backgroundColor = TvGoldAccent.copy(alpha = 0.2f),
                focusedBorderColor = TvGoldAccent,
                focusedScale = 1.04f,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Wallpaper, contentDescription = null, tint = TvGoldAccent)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text("Pilih Gambar dari Storage (SAF)", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        Text("Mendukung JPG, JPEG, PNG, WEBP", color = TvTextSecondary, fontSize = 11.sp)
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text("MODE PENYESUAIAN GAMBAR (SCALE)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TvCyanPrimary)
            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                ScaleMode.values().forEach { mode ->
                    val isSelected = wallpaperConfig.scaleMode == mode
                    TvFocusableCard(
                        onClick = { onChangeScale(mode) },
                        shape = RoundedCornerShape(8.dp),
                        backgroundColor = if (isSelected) TvCyanPrimary.copy(alpha = 0.25f) else Color(0x22FFFFFF),
                        focusedScale = 1.05f,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = mode.label,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) TvCyanPrimary else Color.White
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AppsDockSection(
    installedApps: List<AppItem>,
    onUnhideApp: (AppItem) -> Unit,
    onResetOrder: () -> Unit
) {
    val hiddenApps = remember(installedApps) { installedApps.filter { it.isHidden } }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("MANAJEMEN APLIKASI DOCK", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TvCyanPrimary)
            Spacer(modifier = Modifier.height(4.dp))
            Text("Total ${installedApps.size} aplikasi terpasang di sistem.", color = TvTextSecondary, fontSize = 12.sp)
        }

        item {
            TvFocusableCard(
                onClick = onResetOrder,
                shape = RoundedCornerShape(10.dp),
                backgroundColor = Color(0x3338BDF8),
                focusedScale = 1.04f,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Reset Urutan Dock ke Bawaan", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(4.dp))
            Text("APLIKASI TERSEMBUNYI (${hiddenApps.size})", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TvGoldAccent)
        }

        if (hiddenApps.isEmpty()) {
            item {
                Text("Tidak ada aplikasi yang disembunyikan.", color = TvTextSecondary, fontSize = 12.sp)
            }
        } else {
            items(hiddenApps) { app ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0x33FFFFFF))
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(app.label, color = Color.White, fontSize = 13.sp)
                    Button(
                        onClick = { onUnhideApp(app) },
                        colors = ButtonDefaults.buttonColors(containerColor = TvCyanPrimary),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp)
                    ) {
                        Icon(Icons.Default.Visibility, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.Black)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Tampilkan", fontSize = 11.sp, color = Color.Black)
                    }
                }
            }
        }
    }
}

@Composable
private fun NetworkDeviceSection(context: Context) {
    val netInfo = remember { getNetworkInfo(context) }
    val storageInfo = remember { getStorageInfo() }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("INFORMASI JARINGAN", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TvCyanPrimary)
            Spacer(modifier = Modifier.height(4.dp))
            InfoRow("Koneksi", netInfo.type)
            InfoRow("Alamat IP", netInfo.ipAddress)
            InfoRow("SSID", netInfo.ssid)
            InfoRow("Internet", if (netInfo.hasInternet) "Tersambung" else "Terputus")
        }

        item {
            Spacer(modifier = Modifier.height(6.dp))
            Text("INFORMASI PERANGKAT & STORAGE", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TvCyanPrimary)
            Spacer(modifier = Modifier.height(4.dp))
            InfoRow("Model Perangkat", "Android TV Box B866F")
            InfoRow("OS Target", "Google TV / Android 14 (Kompatibel Android 9+)")
            InfoRow("Internal Storage", "${storageInfo.availableGb} GB bebas dari ${storageInfo.totalGb} GB")
            InfoRow("Status USB", storageInfo.usbStatus)
        }
    }
}

@Composable
private fun WidgetsDisplaySection(
    preferences: LauncherPreferences,
    onUpdatePreferences: ((LauncherPreferences) -> LauncherPreferences) -> Unit
) {
    var apiKeyInput by remember { mutableStateOf(preferences.footballApiKey) }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("PENGATURAN WIDGET", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TvCyanPrimary)
            Spacer(modifier = Modifier.height(6.dp))

            // Toggle Jam Analog
            ToggleRow(
                title = "Widget Jam Analog di Tengah",
                subtitle = "Tampilkan jam jarum klasik dan elegan di tengah layar",
                isChecked = preferences.showAnalogClock,
                onCheckedChange = { checked ->
                    onUpdatePreferences { it.copy(showAnalogClock = checked) }
                }
            )

            // Toggle Widget Sepak Bola
            ToggleRow(
                title = "Widget Sepak Bola di Kiri",
                subtitle = "Tampilkan jadwal dan skor EPL, La Liga, Serie A, dsb.",
                isChecked = preferences.showFootballWidget,
                onCheckedChange = { checked ->
                    onUpdatePreferences { it.copy(showFootballWidget = checked) }
                }
            )

            // Format Jam 24 Jam
            ToggleRow(
                title = "Format Waktu 24 Jam",
                subtitle = "Format HH:mm:ss WIB (Aktif) atau 12 Jam AM/PM",
                isChecked = preferences.is24HourFormat,
                onCheckedChange = { checked ->
                    onUpdatePreferences { it.copy(is24HourFormat = checked) }
                }
            )
        }

        item {
            Spacer(modifier = Modifier.height(6.dp))
            Text("SKALA UKURAN DOCK APLIKASI", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TvCyanPrimary)
            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(
                    Pair("Ringkas", 0.85f),
                    Pair("Normal", 1.0f),
                    Pair("Besar", 1.15f)
                ).forEach { (label, scale) ->
                    val isSelected = kotlin.math.abs(preferences.dockScale - scale) < 0.05f
                    TvFocusableCard(
                        onClick = { onUpdatePreferences { it.copy(dockScale = scale) } },
                        shape = RoundedCornerShape(8.dp),
                        backgroundColor = if (isSelected) TvCyanPrimary.copy(alpha = 0.25f) else Color(0x22FFFFFF),
                        focusedScale = 1.05f,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(label, fontSize = 12.sp, color = if (isSelected) TvCyanPrimary else Color.White)
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(6.dp))
            Text("KONFIGURASI API SEPAK BOLA (OPSIONAL)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TvCyanPrimary)
            Spacer(modifier = Modifier.height(4.dp))
            Text("Masukkan API Key sepak bola resmi (Football-Data / API-Football) jika ada. Launcher memiliki dataset terverifikasi yang bekerja offline out-of-the-box.", fontSize = 11.sp, color = TvTextSecondary)
            Spacer(modifier = Modifier.height(6.dp))

            OutlinedTextField(
                value = apiKeyInput,
                onValueChange = {
                    apiKeyInput = it
                    onUpdatePreferences { p -> p.copy(footballApiKey = it) }
                },
                placeholder = { Text("Contoh: a1b2c3d4e5...", color = Color.Gray, fontSize = 12.sp) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = TvCyanPrimary,
                    unfocusedBorderColor = Color(0x44FFFFFF),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
        }
    }
}

@Composable
private fun HomeSettingsSection(context: Context) {
    var launcherStatus by remember { mutableStateOf(DefaultLauncherHelper.checkLauncherStatus(context)) }

    LaunchedEffect(Unit) {
        launcherStatus = DefaultLauncherHelper.checkLauncherStatus(context)
    }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("PENGATURAN DEFAULT HOME LAUNCHER", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TvCyanPrimary)
            Spacer(modifier = Modifier.height(8.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0x3300E5FF))
                    .padding(12.dp)
            ) {
                Column {
                    Text("STATUS SAAT INI:", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TvCyanPrimary)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = launcherStatus.label,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            TvFocusableCard(
                onClick = {
                    DefaultLauncherHelper.openDefaultLauncherSettings(context)
                },
                shape = RoundedCornerShape(10.dp),
                backgroundColor = TvCyanPrimary,
                focusedScale = 1.04f,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Tetapkan Sebagai Home Default", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "Ketika PRAMANA LAUNCHER dipilih sebagai Home Default, setiap kali tombol HOME pada remote control ditekan, sistem Android TV akan selalu kembali ke launcher ini secara instan.",
                fontSize = 11.sp,
                color = TvTextSecondary,
                lineHeight = 16.sp
            )
        }
    }
}

@Composable
private fun SystemSettingsSection(context: Context) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Text("PENGATURAN SISTEM ANDROID TV", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TvCyanPrimary)
            Spacer(modifier = Modifier.height(4.dp))
        }

        item {
            SystemActionCard(
                title = "Pengaturan Utama Sistem",
                subtitle = "Buka menu pengaturan Android TV OS",
                icon = Icons.Default.Settings,
                onClick = {
                    try {
                        context.startActivity(Intent(Settings.ACTION_SETTINGS).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        })
                    } catch (_: Exception) {}
                }
            )
        }

        item {
            SystemActionCard(
                title = "Pengaturan Wi-Fi & Jaringan",
                subtitle = "Hubungkan ke jaringan nirkabel atau LAN",
                icon = Icons.Default.Router,
                onClick = {
                    try {
                        context.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        })
                    } catch (_: Exception) {}
                }
            )
        }

        item {
            SystemActionCard(
                title = "Pengaturan Aplikasi & Izin",
                subtitle = "Kelola aplikasi dan penyimpanan sistem",
                icon = Icons.Default.Apps,
                onClick = {
                    try {
                        context.startActivity(Intent(Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        })
                    } catch (_: Exception) {}
                }
            )
        }
    }
}

@Composable
private fun SystemActionCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    onClick: () -> Unit
) {
    TvFocusableCard(
        onClick = onClick,
        shape = RoundedCornerShape(10.dp),
        backgroundColor = Color(0x33FFFFFF),
        focusedScale = 1.04f,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = TvCyanPrimary, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Text(subtitle, color = TvTextSecondary, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun AboutSection() {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("TENTANG PRAMANA LAUNCHER", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TvCyanPrimary)
        Spacer(modifier = Modifier.height(4.dp))
        InfoRow("Aplikasi", "PRAMANA LAUNCHER")
        InfoRow("Edisi", "B866F TV Box & Google TV")
        InfoRow("Versi", "1.0.0 (Build 2026)")
        InfoRow("Bahasa", "Indonesia (WIB)")
        InfoRow("Desain", "Glassmorphism UI & Remote D-Pad Navigation")
        InfoRow("Orientasi", "Landscape Fullscreen (16:9 / 4K)")

        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = "Dibuat khusus untuk kenyamanan menonton dan navigasi cepat di Android TV Box B866F tanpa iklan dan tanpa bloatware rekomendasi.",
            fontSize = 11.sp,
            color = TvTextSecondary,
            lineHeight = 16.sp
        )
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = TvTextSecondary, fontSize = 12.sp)
        Text(value, color = Color.White, fontWeight = FontWeight.Medium, fontSize = 12.sp)
    }
}

@Composable
private fun ToggleRow(
    title: String,
    subtitle: String,
    isChecked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = Color.White, fontWeight = FontWeight.Medium, fontSize = 12.sp)
            Text(subtitle, color = TvTextSecondary, fontSize = 10.sp)
        }
        Spacer(modifier = Modifier.width(8.dp))
        Switch(
            checked = isChecked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.Black,
                checkedTrackColor = TvCyanPrimary,
                uncheckedThumbColor = Color.Gray,
                uncheckedTrackColor = Color(0x44FFFFFF)
            )
        )
    }
}
