package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.remote.FootballRepository
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context verifies Pramana Launcher`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("PRAMANA LAUNCHER", appName)
  }

  @Test
  fun `verify football repository has 8 supported leagues`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val repo = FootballRepository(context)
    assertEquals(8, repo.supportedLeagues.size)
  }

  @Test
  fun `verify fixtures load successfully`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val repo = FootballRepository(context)
    val plFixtures = repo.getFixturesForLeague("PL", null)
    assertTrue(plFixtures.isNotEmpty())
  }
}
