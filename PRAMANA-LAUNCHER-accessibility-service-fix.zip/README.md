# PRAMANA LAUNCHER — B866F Android TV & Google TV Edition

**PRAMANA LAUNCHER** adalah peluncur (launcher) native modern dan premium untuk **Android TV Box B866F**, **Google TV OS 14**, dan perangkat Android TV lainnya (kompatibel dari Android 9+ ke atas).

Dirancang khusus dengan estetika **Glassmorphism**, antarmuka landscape fullscreen 16:9 / 4K, dan **100% navigasi ramah remote control D-pad**. Bebas dari iklan, bloatware, maupun rekomendasi konten yang mengganggu.

---

## Fitur Utama

### 1. Desain Home Screen Fullscreen
- **Wallpaper Layar Penuh:** Mendukung wallpaper resolusi tinggi (720p, 1080p, 4K) dengan efek ambient vignette glassmorphism.
- **Header Kiri Atas:** Tulisan khas `B866F LAUNCHER • B866F EDITION`.
- **Jam & Tanggal Digital:** Menampilkan waktu real-time dalam zona **WIB (UTC+7)** dengan nama hari dan tanggal berbahasa Indonesia (contoh: *Sabtu, 31 Oktober 2026 • 20:45 WIB*).
- **5 Ikon Utilitas Cepat (Kanan Atas):**
  1. *Jaringan & Wi-Fi:* Indikator sinyal, dialog alamat IP lokal, nama SSID, dan status internet.
  2. *Penyimpanan & USB:* Kapasitas storage internal bebas/total dan deteksi Flash Drive / USB.
  3. *Mode Audio / Notifikasi:* Toggle senyap/aktif.
  4. *Pengaturan Launcher:* Membuka panel sidebar pengaturan dari kanan.
  5. *Pengaturan Sistem TV:* Membuka pengaturan sistem Android TV (`Settings.ACTION_SETTINGS`).

### 2. Widget Jam Analog di Tengah Layar
- Jam jarum klasik dan elegan di tengah layar.
- Dial semi-transparan dengan ring bezel glowing khas glassmorphism.
- Angka 1 hingga 12 dan tick marks jelas terbaca di layar TV dari kejauhan.
- Jarum jam, jarum menit, dan jarum detik bergerak halus mengikuti waktu sistem tanpa menutupi wallpaper secara berlebihan.

### 3. Widget Jadwal Sepak Bola Real-Time (Sisi Kiri)
- Terletak di sisi kiri dengan kartu glassmorphism transparan.
- **8 Kompetisi Lengkap:**
  1. English Premier League (EPL)
  2. La Liga (Spanyol)
  3. Serie A (Italia)
  4. Bundesliga (Jerman)
  5. Ligue 1 (Prancis)
  6. UEFA Champions League (UCL)
  7. UEFA Europa League (UEL)
  8. Liga 1 Indonesia
- **Fitur Lengkap:** Logo kompetisi, logo klub, nama klub, tanggal, waktu kick-off dalam format WIB, skor real-time, status pertandingan (*LIVE*, *Akan Main*, *Selesai*, *Ditunda*).
- **Offline Cache:** Data tersimpan secara lokal sehingga widget tetap berfungsi ketika koneksi internet terputus.
- **Arsitektur Terpisah:** UI dan DataSource terpisah rapi dengan dukungan konfigurasi API Key mandiri di menu pengaturan.

### 4. Dock Aplikasi Modular di Bawah Layar
- Menampilkan aplikasi yang terpasang melalui `PackageManager` Android TV (`CATEGORY_LEANBACK_LAUNCHER` & `CATEGORY_LAUNCHER`).
- Membuka aplikasi via tombol `OK` / `DPAD_CENTER` / `ENTER`.
- **Mode Edit Urutan:** Geser posisi ikon ke kiri atau kanan sesuai kenyamanan pengguna.
- **Sembunyikan Aplikasi:** Kemampuan menyembunyikan aplikasi yang jarang dipakai dari dock.
- Konfigurasi urutan dan daftar sembunyi disimpan secara persisten di penyimpanan lokal.

### 5. Sidebar Pengaturan Glassmorphism
- Animasi slide-in halus dari sisi kanan layar saat memilih ikon pengaturan atau menekan tombol `MENU` pada remote.
- **7 Menu Pengaturan:**
  1. *Tema & Wallpaper:* Preset Neon Cyber, Nebula Aurora, Dark Minimalist, serta pemilihan foto kustom dari memori perangkat via Storage Access Framework (SAF) dengan pilihan mode *Center Crop*, *Fit*, dan *Stretch*.
  2. *Aplikasi Dock:* Kelola aplikasi tersembunyi dan reset urutan dock ke default.
  3. *Jaringan & Perangkat:* Info IP address, tipe koneksi (Wi-Fi/LAN), SSID, spesifikasi B866F, serta kapasitas memori/USB.
  4. *Widget & Tampilan:* Toggle on/off jam analog, toggle on/off widget sepak bola, format jam 24/12 jam, skala ukuran dock (Ringkas, Normal, Besar), dan input API key sepak bola.
  5. *Pengaturan Home:* Status apakah Pramana Launcher sudah menjadi Home Default, panduan tombol remote, dan jalan pintas RoleManager / Default Apps Settings.
  6. *Pengaturan Sistem:* Jalan pintas langsung ke pengaturan Android TV OS.
  7. *Tentang Launcher:* Informasi versi dan rilis.
- Menekan tombol `BACK` pada remote akan menutup sidebar terlebih dahulu tanpa keluar dari launcher.

### 6. Dukungan Penuh Remote Control D-Pad
- Navigasi mulus dengan `DPAD_UP`, `DPAD_DOWN`, `DPAD_LEFT`, `DPAD_RIGHT`, `DPAD_CENTER`, `BACK`, `HOME`, dan `MENU`.
- Indikator fokus jelas: efek pembesaran skala (1.08x) dan bingkai neon menyala (cyan/gold glow).
- Nol ketergantungan pada layar sentuh (touchscreen tidak diperlukan).

---

## Struktur Modul & Kode

```
app/src/main/
├── AndroidManifest.xml                  // Konfigurasi Leanback, Home Intent, dan Package Visibility
├── java/com/example/
│   ├── MainActivity.kt                 // Activity utama dengan immersive fullscreen & remote key listener
│   ├── data/
│   │   ├── local/
│   │   │   ├── InstalledAppsManager.kt // Pembaca PackageManager & launcher aplikasi
│   │   │   └── LauncherPreferencesManager.kt // Penyimpanan lokal SharedPreferences & DataStore
│   │   ├── model/
│   │   │   ├── AppItem.kt              // Model data aplikasi terpasang
│   │   │   ├── LauncherPreferences.kt  // Konfigurasi widget & preferensi
│   │   │   ├── MatchFixture.kt         // Model jadwal pertandingan sepak bola
│   │   │   └── WallpaperConfig.kt      // Model konfigurasi wallpaper & skala
│   │   └── remote/
│   │       └── FootballRepository.kt   // Repository jadwal sepak bola 8 liga (WIB)
│   └── ui/
│       ├── HomeScreen.kt               // Layout utama TV Home Dashboard
│       ├── LauncherViewModel.kt        // ViewModel state management
│       ├── components/
│       │   ├── AnalogClockWidget.kt    // Jam analog Canvas 1-12 dengan jarum halus
│       │   ├── AppDock.kt              // Dock aplikasi dengan mode reorder & hide
│       │   ├── DefaultLauncherHelper.kt// Pemeriksa RoleManager & Default Home Launcher
│       │   ├── DigitalClockHeader.kt   // Header B866F & tanggal/jam digital Indonesia
│       │   ├── FootballScheduleWidget.kt // Widget sepak bola 8 liga dengan tab navigasi
│       │   ├── SidebarSettings.kt      // Panel 7 menu pengaturan dari kanan
│       │   ├── TopUtilityBar.kt        // 5 ikon utilitas kanan atas & modal info
│       │   ├── TvFocusableCard.kt      // Komponen fokus D-pad M3 dengan animasi glow
│       │   └── WallpaperBackground.kt  // Komponen latar belakang wallpaper & penyesuaian skala
│       └── theme/
│           ├── Color.kt                // Palet warna glassmorphism TV (Cyan, Amber, Glass Dark)
│           ├── Theme.kt                // PramanaLauncherTheme M3 Dark
│           └── Type.kt                 // Tipografi
```
